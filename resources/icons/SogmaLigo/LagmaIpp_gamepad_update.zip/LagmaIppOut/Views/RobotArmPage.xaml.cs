using LagmaIpp.Services;
using LagmaIpp.ViewModels;

namespace LagmaIpp.Views;

public partial class RobotArmPage : ContentPage
{
    private readonly MainViewModel _vm;
    private bool _liveMode = false;

    private readonly List<(string Name, int[] Values)> _presets = new();

    // Badge borders per evidenziare il servo selezionato via gamepad
    private Border[] _servoBadges = null!;
    private readonly Color _badgeActive   = Color.FromArgb("#00D4FF");
    private readonly Color _badgeInactive = Color.FromArgb("#1E2A38");
    private readonly Color _textActive    = Color.FromArgb("#00D4FF");
    private readonly Color _textInactive  = Color.FromArgb("#3D5068");

    // Timer per aggiornare i badge del servo selezionato
    private System.Timers.Timer? _badgeTimer;

    // Mappa indice servo → indice badge (i servo sono in ordine inverso nel layout)
    // Layout: S5=Grip, S3=WristPitch, S4=WristRoll, S2=Elbow, S1=Shoulder, S0=Waist
    // Ordine badge array: [0]=S0, [1]=S1, [2]=S2, [3]=S3, [4]=S4, [5]=S5
    private static readonly int[] ServoToLayout = { 5, 4, 3, 2, 1, 0 }; // badge index per servo N

    public RobotArmPage()
    {
        InitializeComponent();
        _vm = App.ViewModel;
        BindingContext = _vm;

        // Configura GamepadBar
        ArmGamepadBar.AssignedTarget = GamepadTarget.Arm;

        // Raccoglie i badge nell'ordine S0..S5
        _servoBadges = new Border[]
        {
            ServoBadge0, ServoBadge1, ServoBadge2,
            ServoBadge3, ServoBadge4, ServoBadge5
        };

        UpdateLiveModeButton();
        AddDefaultPresets();
        RefreshPresetList();
        StartBadgeTimer();
    }

    protected override void OnDisappearing()
    {
        base.OnDisappearing();
        _badgeTimer?.Stop();
        if (App.Gamepad.Target == GamepadTarget.Arm)
            App.Gamepad.SetTarget(GamepadTarget.None);
    }

    // ════════════════════════════════════════════════════════════
    //  BADGE SERVO SELEZIONATO (highlight visivo per il gamepad)
    // ════════════════════════════════════════════════════════════

    private void StartBadgeTimer()
    {
        _badgeTimer = new System.Timers.Timer(150); // ~7Hz
        _badgeTimer.Elapsed += (_, _) => MainThread.BeginInvokeOnMainThread(UpdateServoBadges);
        _badgeTimer.Start();
    }

    private void UpdateServoBadges()
    {
        bool gpActive = App.Gamepad.Target == GamepadTarget.Arm;
        int selected  = App.Gamepad.SelectedServo; // 0..5

        for (int i = 0; i < _servoBadges.Length; i++)
        {
            bool isSelected = gpActive && (i == selected);
            _servoBadges[i].Stroke        = new SolidColorBrush(isSelected ? _badgeActive : _badgeInactive);
            _servoBadges[i].BackgroundColor = isSelected
                ? Color.FromArgb("#001E30")
                : Color.FromArgb("#0A1628");

            // Aggiorna anche il testo badge
            if (_servoBadges[i].Content is Label lbl)
                lbl.TextColor = isSelected ? _textActive : _textInactive;
        }
    }

    // ════════════════════════════════════════════════════════════
    //  LIVE MODE
    // ════════════════════════════════════════════════════════════

    private void OnLiveModeClicked(object sender, EventArgs e)
    {
        _liveMode = !_liveMode;
        UpdateLiveModeButton();
    }

    private void UpdateLiveModeButton()
    {
        BtnLiveMode.Text = _liveMode ? "◀  Live mode ON" : "◀  Live mode";
        BtnLiveMode.BackgroundColor = _liveMode
            ? Color.FromArgb("#00C853")
            : Color.FromArgb("#FF3B5C");
    }

    // ════════════════════════════════════════════════════════════
    //  PRESET PANEL
    // ════════════════════════════════════════════════════════════

    private void AddDefaultPresets()
    {
        _presets.Add(("Home",   new[] { 90, 90, 90, 90, 90, 120 }));
        _presets.Add(("Riposo", new[] { 90, 30, 60, 90, 90, 90  }));
    }

    private void RefreshPresetList()
    {
        PresetList.Children.Clear();
        for (int i = 0; i < _presets.Count; i++)
        {
            var idx    = i;
            var preset = _presets[i];

            var row = new Border
            {
                BackgroundColor = Color.FromArgb("#0A0E14"),
                Stroke          = new SolidColorBrush(Color.FromArgb("#1E2A38")),
                StrokeThickness = 1,
                Padding         = new Thickness(8, 6)
            };
            row.StrokeShape = new Microsoft.Maui.Controls.Shapes.RoundRectangle
                { CornerRadius = new CornerRadius(6) };

            var grid = new Grid
            {
                ColumnDefinitions = new ColumnDefinitionCollection(
                    new ColumnDefinition(GridLength.Star),
                    new ColumnDefinition(GridLength.Auto))
            };

            var lbl = new Label
            {
                Text           = preset.Name,
                TextColor      = Color.FromArgb("#E8EDF2"),
                FontSize       = 11,
                VerticalOptions = LayoutOptions.Center
            };
            var btn = new Label
            {
                Text           = "▶",
                TextColor      = Color.FromArgb("#00D4FF"),
                FontSize       = 13,
                VerticalOptions = LayoutOptions.Center
            };
            btn.GestureRecognizers.Add(new TapGestureRecognizer
            {
                Command = new Command(() => ApplyPreset(idx))
            });

            grid.Children.Add(lbl); Grid.SetColumn(lbl, 0);
            grid.Children.Add(btn); Grid.SetColumn(btn, 1);

            row.Content = grid;
            PresetList.Children.Add(row);
        }
    }

    private void ApplyPreset(int idx)
    {
        if (idx < 0 || idx >= _presets.Count) return;
        var v = _presets[idx].Values;
        _vm.Servo0 = v[0]; _vm.Servo1 = v[1]; _vm.Servo2 = v[2];
        _vm.Servo3 = v[3]; _vm.Servo4 = v[4]; _vm.Servo5 = v[5];
    }

    private async void OnPresetPlayClicked(object sender, EventArgs e) => ApplyPreset(0);

    private async void OnSavePresetClicked(object sender, EventArgs e)
    {
        var name = await DisplayPromptAsync("Salva Preset", "Nome del preset:", "Salva", "Annulla",
            "es: Posa 1", maxLength: 20);
        if (string.IsNullOrWhiteSpace(name)) return;
        _presets.Add((name, new[] { _vm.Servo0, _vm.Servo1, _vm.Servo2,
                                    _vm.Servo3, _vm.Servo4, _vm.Servo5 }));
        RefreshPresetList();
    }

    private async void OnDeletePresetClicked(object sender, EventArgs e)
    {
        if (_presets.Count == 0) return;
        var names  = _presets.Select(p => p.Name).ToArray();
        var choice = await DisplayActionSheetAsync("Elimina preset", "Annulla", null, names);
        var idx    = _presets.FindIndex(p => p.Name == choice);
        if (idx >= 0) { _presets.RemoveAt(idx); RefreshPresetList(); }
    }

    private async void OnPresetClicked(object sender, EventArgs e)
    {
        var result = await DisplayActionSheetAsync("Preset rapido", "Annulla", null,
            "Home (tutti 90°)", "Riposo", "Pinza aperta", "Pinza chiusa");
        switch (result)
        {
            case "Home (tutti 90°)":  SetAllServos(90, 90, 90, 90, 90, 120); break;
            case "Riposo":            SetAllServos(90, 30, 60, 90, 90, 90);  break;
            case "Pinza aperta":      _vm.Servo5 = 120; break;
            case "Pinza chiusa":      _vm.Servo5 = 30;  break;
        }
    }

    private void SetAllServos(int s0, int s1, int s2, int s3, int s4, int s5)
    {
        _vm.Servo0 = s0; _vm.Servo1 = s1; _vm.Servo2 = s2;
        _vm.Servo3 = s3; _vm.Servo4 = s4; _vm.Servo5 = s5;
    }
}
